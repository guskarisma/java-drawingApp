package drawingApp;


import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.RenderingHints;

public class PaintingSet extends JPanel{
	Canvas canvas;
	Palette palette;
	Brushes brushes;
	
	public PaintingSet(){
		canvas=new Canvas();
		palette=new Palette();
		brushes=new Brushes();
		this.setLayout(new BorderLayout());
		this.add(palette,BorderLayout.SOUTH);
		this.add(brushes,BorderLayout.WEST);
		this.add(canvas,BorderLayout.CENTER);
	}//------------------------------------------------------	
	
	private class Shape{
		int width=20;
		int height=20;
		int x;
		int y;
		int type;//1=rect,2=oval
		Color color;
		public Shape(int xValue, int yValue,int shapeType,Color shapeColor){
			type=shapeType;
			color=shapeColor;
			x=xValue;
			y=yValue;
		}
		public void paintShape(Graphics g){
			g.setColor(color);
			if(type==1){
				g.fillRect(x-10,y-10,width,height);
			}
			else{
				g.fillOval(x-10, y-10, width, height);
			}
		}
	}////////////////////////////////////////////////////////
	private class Canvas extends JPanel{
		int shapeType;
		Color colorSelected;
		ArrayList<Shape> shapes=new ArrayList<Shape>();
		public Canvas(){
			shapeType=1;
			colorSelected=Color.getHSBColor(0/6f, 1, 1);
			this.addMouseListener(new Paint());
			this.addMouseMotionListener(new Paint());
		}
		public void paintComponent(Graphics g){
			super.paintComponent(g);			
			this.setBackground(Color.WHITE);
			for(int i=0;i<shapes.size();i++){
				Shape s=shapes.get(i);
				s.paintShape(g);
			}
		}
		public void setType(int type){
			shapeType=type;
		}
		public void setColor(Color color){
			colorSelected=color;
		}
		private class Paint extends MouseAdapter{			
			int initX;
			int initY;
			int currentX;
			int currentY;
			public void mousePressed(MouseEvent e){
				currentX=e.getX();
				currentY=e.getY();				
				shapes.add(new Shape(currentX,currentY,shapeType,colorSelected));
				repaint();
			}
			public void mouseDragged(MouseEvent e){
				initX=currentX;
				initY=currentY;
				currentX=e.getX();
				currentY=e.getY();
				if(Math.abs(currentX-initX)>0 || Math.abs(currentY-initY)>0){
					shapes.add(new Shape(currentX,currentY,shapeType,colorSelected));
				}
				repaint();				
			}			
		}
	}////////////////////////////////////////////////////////
	private class Palette extends JPanel implements MouseListener{
		ColorSelector selector=new ColorSelector();
		int width;
		int height;
		public Palette(){
			this.setPreferredSize(new Dimension(800,50));
			width= 50;
			height=50;
			this.addMouseListener(this);
		}
		public void paintComponent(Graphics g){
			super.paintComponent(g);
			int x=0;
			int y=0;		
			for(int i=0;i<6;i++){				
				g.setColor(Color.getHSBColor(i/6f, 1.0f, 1.0f));
				g.fillRect(x, y,width,height);
				x+=50;			
			}
			selector.drawSelector(g);
		}
		private class ColorSelector{
			int x;
			public ColorSelector(){
				x=0;
			}
			public void setX(int xValue){
				x=xValue;
			}
			public void drawSelector(Graphics g){
				g.setColor(Color.BLACK);
				g.drawRect(x, 0, 50, 50);
			}
		}
		
		public void mousePressed(MouseEvent e){
			int x=e.getX();
			int i=0;
			if(x<=300){
				if(x<=50){			
					selector.setX(0);
					i=0;
				}
				else if(x<=100){
					selector.setX(50);
					i=1;
				}
				else if(x<=150){
					selector.setX(100);
					i=2;
				}
				else if(x<=200){
					selector.setX(150);
					i=3;
				}
				else if(x<=250){
					selector.setX(200);
					i=4;
				}
				else if(x<=300){
					selector.setX(250);
					i=5;
				}
			}
			repaint();
			canvas.setColor(Color.getHSBColor(i/6f,1,1));
		}
		public void mouseEntered(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mouseClicked(MouseEvent e){}
	}////////////////////////////////////////////////////////
	private class Brushes extends JPanel implements MouseListener{
		BrushSelector selector=new BrushSelector();
		public Brushes(){
			this.setPreferredSize(new Dimension(50,600));
			this.addMouseListener(this);
		}
		public void paintComponent(Graphics g){
			super.paintComponent(g);
			Graphics2D g2=(Graphics2D)g;
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			int width=this.getWidth();
			int height=50;
			g2.setColor(Color.BLACK);
			g2.drawRect(width/4, height/4, width/2, height/2);
			g2.drawOval(width/4, 50+(height/4), width/2, height/2);
			selector.drawSelector(g2);
		}	
		private class BrushSelector{
			int y;
			public BrushSelector(){
				y=0;
			}
			public void setY(int yValue){
				y=yValue;
			}
			public void drawSelector(Graphics g){
				g.setColor(Color.BLACK);
				g.drawRect(0, y, 49, 49);
			}
		}
		public void mousePressed(MouseEvent e){
			int y=e.getY();
			if(y<=100){
				if(y<=50){			
					selector.setY(0);
					canvas.setType(1);
				}
				else if(y<=100){
					selector.setY(50);
					canvas.setType(2);
				}				
			}
			repaint();
		}
		public void mouseEntered(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mouseClicked(MouseEvent e){}
	}////////////////////////////////////////////////////////
}
