package drawingApp;
import javax.swing.JFrame;

public class AppLauncher extends JFrame{
	public AppLauncher(){
		this.setTitle("Simple Paint App");
		this.setContentPane(new PaintingSet());
		this.setSize(800,600);
		this.setLocation(200,50);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args){
		AppLauncher paintingApp=new AppLauncher();
		paintingApp.setVisible(true);
	}
}
